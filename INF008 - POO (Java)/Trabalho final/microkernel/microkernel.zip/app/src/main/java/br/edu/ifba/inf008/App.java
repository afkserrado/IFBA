package br.edu.ifba.inf008;

import br.edu.ifba.inf008.shell.Core;

// Classe que representa a aplicação
public class App {
    public static void main(String[] args) {

        // Inicializa o núcleo (core) da aplicação
        Core.init();
    }
}
