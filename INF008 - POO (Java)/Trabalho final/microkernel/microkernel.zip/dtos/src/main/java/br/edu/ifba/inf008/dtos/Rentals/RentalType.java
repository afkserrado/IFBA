package br.edu.ifba.inf008.dtos.Rentals;

// Deve ser exatamente igual ao banco
public enum RentalType {
    DAILY,
    WEEKLY,
    MONTHLY,
    HOURLY
}
