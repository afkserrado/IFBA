package br.edu.ifba.inf008.dtos.Vehicles;

// Deve ser exatamente igual ao banco
public enum Transmission {
    MANUAL,
    AUTOMATIC
}
